import flet as ft
from datetime import datetime
import time

def main(page: ft.Page):
    page.title = "eat & think"
    page.bgcolor = ft.colors.LIGHT_BLUE_50
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = "adaptive"

    header = ft.Text(
        "Gain the Brain\nYour only limit is your imagination",
        style=ft.TextStyle(size=32, weight=ft.FontWeight.BOLD, color=ft.colors.DEEP_PURPLE_900), text_align= ft.TextAlign.CENTER
    )
    page.add(header)

    # Function to convert time string to datetime object
    def convert_to_datetime(time_str):
        return datetime.strptime(time_str, "%I:%M %p")

    # Function to calculate time difference
    def calculate_time_difference(target_time):
        current_time = datetime.now()
        target_datetime = convert_to_datetime(target_time).replace(year=current_time.year, month=current_time.month, day=current_time.day)
        if current_time > target_datetime:
            return "You should have eaten your meal"
        else:
            time_diff = target_datetime - current_time
            hours, remainder = divmod(time_diff.seconds, 3600)
            minutes, _ = divmod(remainder, 60)
            return f"Time left: {hours}h {minutes}m"

    # Define initial target times
    cube1_time = "08:00 AM"
    cube2_time = "02:00 PM"
    cube3_time = "08:00 PM"
    
    # Determine initial cube colors
    cube1_bgcolor = ft.colors.BLUE_600
    cube2_bgcolor = ft.colors.BLUE_600
    cube3_bgcolor = ft.colors.BLUE_600

    # Function to change the color of the cubes to green when pressed and text entered
    def change_to_green(button, label, time_label, input_text):
        def handler(e):
            if input_text.value.strip():  # Check if input text is not empty
                button.bgcolor = ft.colors.GREEN_600
                label.value = "Good job!"
                time_label.value = ""
                add_calories(input_text.value)  # Add calories when button is pressed
                input_text.value = ""  # Clear input field
                page.update()
        return handler

    # Function to add calories to the total
    total_calories = 0

    def add_calories(calories_str):
        nonlocal total_calories
        try:
            calories = int(calories_str)
            total_calories += calories
            calorie_counter.value = f"Calories: {total_calories}"
        except ValueError:
            pass  # Ignore if input is not a valid integer

    # Create IconButton, labels, and input fields
    buttons = []
    time_labels = []
    status_labels = []
    input_texts = []

    # Function to handle timer picker change
    def handle_timer_picker_change(i):
        def handler(e):
            # Update the selected time in AM/PM format
            selected_time = time.strftime("%I:%M %p", time.gmtime(int(e.data)))
            if i == 0:
                nonlocal cube1_time
                cube1_time = selected_time
            elif i == 1:
                nonlocal cube2_time
                cube2_time = selected_time
            elif i == 2:
                nonlocal cube3_time
                cube3_time = selected_time
            page.update()
        return handler

    for i, (cube_time, bgcolor) in enumerate(zip([cube1_time, cube2_time, cube3_time], [cube1_bgcolor, cube2_bgcolor, cube3_bgcolor])):
        button = ft.IconButton(
            icon=ft.icons.CHECK_BOX_OUTLINE_BLANK,
            icon_size=0,  # Make the icon invisible
            width=150,
            height=150,
            bgcolor=bgcolor
        )
        time_label = ft.Text(calculate_time_difference(cube_time), style=ft.TextStyle(color=ft.colors.RED_600, size=16))
        status_label = ft.Text("", style=ft.TextStyle(color=ft.colors.GREEN_600, size=16))
        input_text = ft.TextField(
            width=200,
        )

        button.on_click = change_to_green(button, status_label, time_label, input_text)

        buttons.append(button)
        time_labels.append(time_label)
        status_labels.append(status_label)
        input_texts.append(input_text)

        # Create Cupertino Timer Picker
        cupertino_timer_picker = ft.CupertinoTimerPicker(
            value=3600,
            second_interval=10,
            minute_interval=1,
            mode=ft.CupertinoTimerPickerMode.HOUR_MINUTE_SECONDS,
            on_change=handle_timer_picker_change(i),
        )

        row_controls = [
            button,
            ft.Column(
                controls=[
                    ft.CupertinoButton(
                        content=ft.Text(
                            value=cube_time,
                            size=24,
                            color=ft.cupertino_colors.BLACK,
                        ),
                        on_click=lambda e, picker=cupertino_timer_picker: page.open(
                            ft.CupertinoBottomSheet(
                                picker,
                                height=216,
                            )
                        ),
                    ),
                    time_label,
                    status_label,
                    input_text
                ],
                alignment=ft.MainAxisAlignment.CENTER
            )
        ]

        page.add(ft.Row(controls=row_controls, alignment=ft.MainAxisAlignment.CENTER))

    # Create calorie input field and counter
    calorie_input = ft.TextField(
        width=200,
    )

    calorie_counter = ft.Text(
        "Calories: 0",
        style=ft.TextStyle(color=ft.colors.BLACK, size=32 )
    ) 

    def update_calorie_counter(e):
        add_calories(calorie_input.value)
        calorie_input.value = ""  # Clear input after submission
        page.update()

    submit_icon = ft.icons.ARROW_FORWARD
    submit_button = ft.IconButton(
        icon=submit_icon,
        icon_size=24,
        bgcolor=ft.colors.BLUE_500,
        on_click=update_calorie_counter,
    )

    page.add(
        ft.Row(
            controls=[calorie_input, submit_button],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

    page.add(
        ft.Row(
            controls=[calorie_counter],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

ft.app(target=main)
#ft.app(target=main, view=ft.AppView.WEB_BROWSER)
